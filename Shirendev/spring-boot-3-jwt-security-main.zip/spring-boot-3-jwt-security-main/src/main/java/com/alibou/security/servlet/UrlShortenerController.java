package com.alibou.security.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import java.io.IOException;

@RestController
public class UrlShortenerController  {


    @GetMapping("/app")
    public RedirectView redirectToApp(HttpServletRequest request) {

        String userAgent = request.getHeader("User-Agent");
        String redirectUrl = "https://apps.apple.com/us/app/bogd-mobile/id1475442374";  // Default to iOS if unknown

        // Check the User-Agent header to detect Android or iOS
        if (userAgent != null) {
            if (userAgent.contains("Android")) {
                redirectUrl = "https://play.google.com/store/apps/details?id=com.bogdbank.ebank.v2";  // Android link
            } else if (userAgent.contains("iPhone") || userAgent.contains("iPad")) {
                redirectUrl = "https://apps.apple.com/us/app/bogd-mobile/id1475442374";  // iOS link
            } else if (userAgent.contains("Windows")) {
                redirectUrl = "https://apps.apple.com/us/app/bogd-mobile/id1475442374";  // Desktop (Windows) link
            } else if (userAgent.contains("Mac")) {
                redirectUrl = "https://apps.apple.com/us/app/bogd-mobile/id1475442374";  // Desktop (Mac) link
            }
        }

        return new RedirectView(redirectUrl);
    }
}
