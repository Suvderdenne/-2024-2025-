package com.alibou.security.modal;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "marketData") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MarketData {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long marketDataId;

    @ManyToOne
    @JoinColumn(name = "asset_id", nullable = false)
    private Asset asset;  // Represents the asset for which the market data is recorded

    @Column(nullable = false)
    private BigDecimal openPrice;  // Opening price of the asset during the period

    @Column(nullable = false)
    private BigDecimal closePrice;  // Closing price of the asset during the period

    @Column(nullable = false)
    private BigDecimal highPrice;  // Highest price during the period

    @Column(nullable = false)
    private BigDecimal lowPrice;  // Lowest price during the period

    @Column(nullable = false)
    private BigDecimal lastPrice;  // Last traded price

    @Column(nullable = false)
    private BigDecimal volume;  // Trading volume during the period

    @Column(nullable = false)
    private BigDecimal bidPrice;  // The highest price the buyer is willing to pay

    @Column(nullable = false)
    private BigDecimal askPrice;  // The lowest price the seller is willing to sell for

    @Column(nullable = false)
    private LocalDateTime timestamp;  // The timestamp when the market data was recorded

    @Column(nullable = false)
    private String source;  // Source of the market data (exchange name, API, etc.)

}
