package com.alibou.security.repository;

import com.alibou.security.modal.Investment;
import com.alibou.security.modal.MarketData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarketDataRepository extends JpaRepository<MarketData, Long> {


}
