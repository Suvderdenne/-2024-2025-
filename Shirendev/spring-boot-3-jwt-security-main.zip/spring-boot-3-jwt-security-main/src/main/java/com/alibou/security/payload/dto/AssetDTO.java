package com.alibou.security.payload.dto;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class AssetDTO {

    private Long assetId;
    private String type;  // Type of asset (e.g., "Stock", "Bond", "Crypto")
    private String symbol;  // The ticker symbol or code (e.g., "AAPL" for Apple)
    private String name;  // Full name or description of the asset (e.g., "Apple Inc.")
    private BigDecimal currentPrice;  // The current market price of the asset
    private BigDecimal marketCap;  // The market capitalization of the asset (optional)
    private BigDecimal volume;  // The trading volume of the asset (optional)
    private String currency;  // Currency in which the asset is traded (e.g., "USD")
    private String status;  // Status of the asset (e.g., "active", "inactive")
    private LocalDateTime createdAt;  // The date and time when the asset was added to the system
    private LocalDateTime updatedAt;  // The date and time when the asset data was last updated
    private String  iconBase64;
}
