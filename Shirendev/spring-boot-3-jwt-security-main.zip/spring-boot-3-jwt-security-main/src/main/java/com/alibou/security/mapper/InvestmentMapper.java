package com.alibou.security.mapper;

import com.alibou.security.modal.Investment;
import com.alibou.security.payload.dto.InvestmentDTO;

public class InvestmentMapper {


    public static InvestmentDTO mapToDTO(Investment investment){
        InvestmentDTO investmentDTO=new InvestmentDTO();
        investmentDTO.setInvestmentId(investment.getInvestmentId());
        investmentDTO.setInvestmentType(investment.getInvestmentType());
        investmentDTO.setPortfolio(investment.getPortfolio());
        investmentDTO.setAmountInvested(investment.getAmountInvested());
        investmentDTO.setCurrency(investment.getCurrency());
        investmentDTO.setInvestmentStatus(investment.getInvestmentStatus());
        investmentDTO.setPurchaseDate(investment.getPurchaseDate());
        investmentDTO.setCurrentValue(investment.getCurrentValue());
        investmentDTO.setCreatedAt(investment.getCreatedAt());
        investmentDTO.setUpdatedAt(investment.getUpdatedAt());
        return investmentDTO;
    }
}
