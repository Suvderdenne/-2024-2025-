package com.alibou.security.repository;


import com.alibou.security.modal.Investment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface InvestmentRepository extends JpaRepository<Investment, Long> {


    @Query(
            "select a from Investment a where" +
//                    "(lower(a.investmentType) like lower(concat('%', :keyword, '%')) OR  " +
//                    "lower(a.name) like lower(concat('%', :keyword, '%')) OR " +
                    "(lower(a.investmentType) like lower(concat('%', :keyword, '%')))"
    )
    List<Investment> searchInvestmentBy(@Param("keyword") String keyword);

}
