package com.alibou.security.service;

import com.alibou.security.modal.Asset;
import com.alibou.security.modal.Investment;
import com.alibou.security.payload.dto.AssetDTO;
import com.alibou.security.payload.dto.InvestmentDTO;
import com.alibou.security.payload.dto.UserDTO;

import java.util.List;

public interface AssetService {


    List<Asset> getAllAssets();

    Asset createAssets(AssetDTO assetDTO, UserDTO user);

    Asset updateAssets(AssetDTO assetDTO, UserDTO user, Long assetId);

    List<Asset> getAssetsLists();

    Asset getAssetsById(Long assetId);

    Asset findBySymbol(String symbol);

    List<Asset> searchAssetsBy(String type);
}
