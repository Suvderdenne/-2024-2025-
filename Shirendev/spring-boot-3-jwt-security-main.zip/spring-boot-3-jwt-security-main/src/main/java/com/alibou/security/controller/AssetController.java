package com.alibou.security.controller;

import com.alibou.security.exception.UserException;
import com.alibou.security.mapper.AssetMapper;
import com.alibou.security.modal.Asset;
import com.alibou.security.payload.dto.AssetDTO;
import com.alibou.security.payload.dto.UserDTO;
import com.alibou.security.service.AssetService;
import com.alibou.security.user.User;
import com.alibou.security.repository.UserRepository;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/asset")
@RequiredArgsConstructor
public class AssetController {
    private static final String SECRET_KEY = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";

    private final AssetService assetService;
    private final UserRepository userRepository;

    @PostMapping
    public ResponseEntity<AssetDTO> createAsset(
            @RequestBody AssetDTO assetDTO,
            HttpServletRequest request
    ) throws UserException {
        String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            // Extract the token after "Bearer " prefix
            String token = authorizationHeader.substring(7);
            System.out.println("Bearer token: " + token);
            String string = getUserIdFromToken(token);
            System.out.println(string);
            System.out.println("Bearer token: " + string);

            User user  = userRepository.findByEmail(string).orElseThrow(() -> new RuntimeException("User not found with email: " + string));
            UserDTO userDTO = new UserDTO();
            System.out.println("user.getId()"+ user.getUserId());
            userDTO.setId(user.getUserId());
            Asset asset = assetService.createAssets(assetDTO, userDTO);
            AssetDTO assetDTO1 = AssetMapper.mapToDTO(asset);
            return ResponseEntity.ok(assetDTO1);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }



    private String getUserIdFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getSubject();  // This is typically the user ID stored in the 'sub' claim
    }
}
