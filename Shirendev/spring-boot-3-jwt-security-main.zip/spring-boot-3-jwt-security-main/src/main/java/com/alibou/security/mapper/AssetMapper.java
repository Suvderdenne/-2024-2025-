package com.alibou.security.mapper;

import com.alibou.security.modal.Asset;
import com.alibou.security.payload.dto.AssetDTO;
import java.util.Base64;


public class AssetMapper {


    public static AssetDTO mapToDTO(Asset asset){
        AssetDTO assetDTO =new AssetDTO();
        assetDTO.setAssetId(asset.getAssetId());
        assetDTO.setType(asset.getType());
        assetDTO.setSymbol(asset.getSymbol());
        assetDTO.setName(asset.getName());
        assetDTO.setCurrentPrice(asset.getCurrentPrice());
        assetDTO.setMarketCap(asset.getMarketCap());
        assetDTO.setVolume(asset.getVolume());
        assetDTO.setCurrency(asset.getCurrency());
        assetDTO.setStatus(asset.getStatus());
        assetDTO.setCreatedAt(asset.getCreatedAt());
        assetDTO.setUpdatedAt(asset.getUpdatedAt());

        if (asset.getIcon() != null) {
            assetDTO.setIconBase64(Base64.getEncoder().encodeToString(asset.getIcon()));
        }
        return assetDTO;
    }
}
