package com.alibou.security.service;

import java.util.List;

import com.alibou.security.exception.UserException;
import com.alibou.security.user.User;


public interface UserService {
    User createUser(User user);
    User getUserById(Long id) throws UserException;
    List<User> getAllUsers();
    void deleteUser(Long id) throws UserException;
    User updateUser(String email, User user) throws UserException;

}
