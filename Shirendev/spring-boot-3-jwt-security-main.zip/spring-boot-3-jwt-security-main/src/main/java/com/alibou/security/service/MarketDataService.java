package com.alibou.security.service;

import com.alibou.security.modal.Asset;
import com.alibou.security.modal.MarketData;
import com.alibou.security.repository.AssetRepository;
import com.alibou.security.repository.MarketDataRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MarketDataService {

    private final RestTemplate restTemplate;
    private final MarketDataRepository repository;
    private final AssetRepository assetRepository;

    public MarketData fetchAndSaveMarketData(String symbol) {
        // Example using Alpha Vantage

//        HttpClient client = HttpClient.newHttpClient();
//        HttpRequest request = HttpRequest.newBuilder()
//                .uri(URI.create("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=MSFT&apikey=TPQBWLTK52LPPRXX"))
//                .build();
//
//        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//        System.out.println(response.body());
        String apiKey = "TPQBWLTK52LPPRXX";
        String url = "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=" + symbol + "&apikey=" + apiKey;

        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
        Map<String, String> quote = (Map<String, String>) response.getBody().get("Global Quote");

        Asset asset = assetRepository.findBySymbol(symbol);

        MarketData data = new MarketData();
        data.setAsset(asset);
        data.setOpenPrice(new BigDecimal(quote.get("02. open")));
        data.setClosePrice(new BigDecimal(quote.get("08. previous close")));
        data.setHighPrice(new BigDecimal(quote.get("03. high")));
        data.setLowPrice(new BigDecimal(quote.get("04. low")));
        data.setLastPrice(new BigDecimal(quote.get("05. price")));
        data.setVolume(new BigDecimal(quote.get("06. volume")));
        data.setBidPrice(BigDecimal.ZERO); // not provided by this API
        data.setAskPrice(BigDecimal.ZERO); // not provided by this API
        data.setTimestamp(LocalDateTime.now());
        data.setSource("Alpha Vantage");

        return repository.save(data);
    }
}
