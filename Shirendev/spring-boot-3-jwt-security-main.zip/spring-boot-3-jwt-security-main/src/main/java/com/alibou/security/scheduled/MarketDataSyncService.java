package com.alibou.security.scheduled;


import com.alibou.security.modal.MarketData;
import com.alibou.security.service.MarketDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MarketDataSyncService {
    private final MarketDataService marketDataService;

//    @Scheduled(cron = "0 0 6 * * *")  // Runs every day at 6 AM server time
    @Scheduled(cron = "0 */15 * * * *")  // Runs Every 15 mins
    public void syncDailyMarketData() {
        System.out.println("Running daily market data sync...");

        // You can loop over asset symbols
        List<String> symbols = List.of("MSFT", "AAPL");

        for (String symbol : symbols) {
            try {
                MarketData data = marketDataService.fetchAndSaveMarketData(symbol);
                System.out.println("Synced: " + symbol);
            } catch (Exception e) {
                System.err.println("Failed to sync " + symbol + ": " + e.getMessage());
            }
        }
    }
}
