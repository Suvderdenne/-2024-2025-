package com.alibou.security.payload.dto;

import com.alibou.security.modal.Portfolio;
import com.alibou.security.user.User;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class InvestmentDTO {

    private Long investmentId;

    private User user;  // The user who made the investment


    private Portfolio portfolio;  // The portfolio in which the investment is held

    private String investmentType;  // Type of the investment (e.g., "stock", "bond", "mutual fund")

    private BigDecimal amountInvested;  // The amount of money invested

    private String currency;  // Currency of the investment (e.g., "USD")

    private String investmentStatus;  // Status of the investment (e.g., "active", "closed")

    private LocalDateTime purchaseDate;  // Date when the investment was made

    private BigDecimal currentValue;  // The current value of the investment

    private LocalDateTime createdAt;  // Record creation timestamp

    private LocalDateTime updatedAt;  // Record last updated timestamp
}
