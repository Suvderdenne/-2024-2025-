package com.alibou.security.service.impl;

import com.alibou.security.modal.Investment;
import com.alibou.security.payload.dto.InvestmentDTO;
import com.alibou.security.payload.dto.UserDTO;
import com.alibou.security.repository.InvestmentRepository;
import com.alibou.security.service.InvestmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;



@Service
@RequiredArgsConstructor
public class InvestmentServiceImpl implements InvestmentService {

    private final InvestmentRepository investmentRepository;

    @Override
    public List<Investment> getAllInvestments() {

        return List.of();
    }

    @Override
    public Investment createInvestments(InvestmentDTO req, UserDTO user) {
        Investment investment=new Investment();
//        investment.setName(req.getName());
//        investment.setType(req.getType());
//        investment.setSymbol(req.getSymbol());
//        investment.setUrl_icon(req.getUrl_icon());
        return investmentRepository.save(investment);
    }

    @Override
    public Investment updateInvestments(InvestmentDTO assets, UserDTO user, Long assetId) {
        return null;
    }

    @Override
    public List<Investment> getInvestmentsLists() {
        return investmentRepository.findAll();
    }

    @Override
    public Investment getInvestmentsById(Long assetId) {
        return null;
    }

    @Override
    public List<Investment> searchInvestmentsBy(String type) {
        return List.of();
    }
}
