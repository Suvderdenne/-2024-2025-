package com.alibou.security.demo;

import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class DemoController {
  private static final String SECRET_KEY = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";


  @GetMapping("/user/profile")
  public String getUserProfile(HttpServletRequest request) {
    // Extract the Authorization header from the request
    String authorizationHeader = request.getHeader("Authorization");

    if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
      // Extract the token after "Bearer " prefix
      String token = authorizationHeader.substring(7);
      System.out.println( "Bearer token: " + token);
            String string = getUserIdFromToken(token);
            System.out.println(string );
      return "Bearer token: " + string;
    } else {
      return "No Bearer token found";
    }
//    String authorizationHeader = request.getHeader("Authorization");
//      String string = getUserIdFromToken(authorizationHeader);
//    System.out.println(string );
//    return "All Headers: " + string;
  }

  @GetMapping("/user/assets")
  public String getUserAssets(@AuthenticationPrincipal String userId) {
    // Fetch user's assets from the database based on the userId
    return "Fetching assets for user: " + userId;
  }

  private String getUserIdFromToken(String token) {
    return Jwts.parser()
            .setSigningKey(SECRET_KEY)
            .parseClaimsJws(token)
            .getBody()
            .getSubject();  // This is typically the user ID stored in the 'sub' claim
  }
}
