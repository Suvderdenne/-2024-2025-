package com.alibou.security.controller;

import com.alibou.security.exception.UserException;
import com.alibou.security.repository.UserRepository;
import com.alibou.security.service.UserService;
import com.alibou.security.user.User;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {
    private static final String SECRET_KEY = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";

    private final UserService userService;
    private final UserRepository repository;

    @PutMapping
    public ResponseEntity<User> updateUser(@RequestBody User userDTO,
                                           HttpServletRequest request) throws Exception{
        String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            // Extract the token after "Bearer " prefix
            String token = authorizationHeader.substring(7);
            System.out.println("Bearer token: " + token);
            String string = getUserIdFromToken(token);
            System.out.println(string);
            System.out.println("Bearer token: " + string);
            User updateUser =userService.updateUser(string, userDTO);

            return new ResponseEntity<>(updateUser, HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }


    }

    private String getUserIdFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getSubject();  // This is typically the user ID stored in the 'sub' claim
    }
    @GetMapping("/{id}")
public ResponseEntity<?> getUserById(@PathVariable Long id, HttpServletRequest request) throws UserException {
    String authorizationHeader = request.getHeader("Authorization");
    
    if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
        String token = authorizationHeader.substring(7);
        try {
            // Optional: verify token here (already done by parsing subject)
            String subject = getUserIdFromToken(token);
            System.out.println("Token verified for user: " + subject);
            
            User user = userService.getUserById(id);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
        }
    } else {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authorization header missing");
    }
}

}
