package com.alibou.security.repository;

import com.alibou.security.exception.UserException;
import com.alibou.security.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

//  @Query(
//          "select a from User a where" +
//                  "(lower(a.email) like lower(concat('%', :email, '%')))"
//  )
  Optional<User> findByEmail(String email);

}
