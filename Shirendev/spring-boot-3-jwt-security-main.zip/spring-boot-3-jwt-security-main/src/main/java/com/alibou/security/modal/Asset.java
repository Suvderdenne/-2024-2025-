package com.alibou.security.modal;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "asset") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Asset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long assetId;

    @Column(nullable = false)
    private String type;  // Type of asset (e.g., "Stock", "Bond", "Crypto")

    @Column(nullable = false, unique = true)
    private String symbol;  // The ticker symbol or code (e.g., "AAPL" for Apple)

    @Column(nullable = false)
    private String name;  // Full name or description of the asset (e.g., "Apple Inc.")

    @Column(nullable = false)
    private BigDecimal currentPrice;  // The current market price of the asset

    @Column
    private BigDecimal marketCap;  // The market capitalization of the asset (optional)

    @Column
    private BigDecimal volume;  // The trading volume of the asset (optional)

    @Column(nullable = false)
    private String currency;  // Currency in which the asset is traded (e.g., "USD")

    @Column(nullable = false)
    private String status;  // Status of the asset (e.g., "active", "inactive")

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;  // The date and time when the asset was added to the system

    @Column(nullable = false)
    private LocalDateTime updatedAt;  // The date and time when the asset data was last updated

    // 🔽 New field for the icon
    @Lob
    @Column(columnDefinition = "BLOB")
    private byte[] icon;
}
