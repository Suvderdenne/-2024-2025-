package com.alibou.security.controller;


//import com.alibou.security.modal.Assets;
import com.alibou.security.exception.UserException;
import com.alibou.security.mapper.InvestmentMapper;
import com.alibou.security.modal.Investment;
import com.alibou.security.payload.dto.InvestmentDTO;
import com.alibou.security.payload.dto.UserDTO;
import com.alibou.security.service.InvestmentService;
import com.alibou.security.user.User;
import com.alibou.security.repository.UserRepository;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/investment")
@RequiredArgsConstructor
public class InvestmentController {
    private static final String SECRET_KEY = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";

    private final InvestmentService investmentService;
    private final UserRepository userRepository;

    @PostMapping
    public ResponseEntity<InvestmentDTO> createSalon(
            @RequestBody InvestmentDTO investmentDTO,
            HttpServletRequest request
            ) throws UserException {
        String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            // Extract the token after "Bearer " prefix
            String token = authorizationHeader.substring(7);
            System.out.println("Bearer token: " + token);
            String string = getUserIdFromToken(token);
            System.out.println(string);
            System.out.println("Bearer token: " + string);

            User user  = userRepository.findByEmail(string).orElseThrow(() -> new RuntimeException("User not found with email: " + string));
        UserDTO userDTO = new UserDTO();
            System.out.println("user.getId()"+ user.getUserId());
        userDTO.setId(user.getUserId());
        Investment investment = investmentService.createInvestments(investmentDTO, userDTO);
        InvestmentDTO investmentDTO1 = InvestmentMapper.mapToDTO(investment);
        return ResponseEntity.ok(investmentDTO1);
        }else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }

    @GetMapping()
    public ResponseEntity<List<InvestmentDTO>> getInvestments() {
        List<Investment> investments=investmentService.getInvestmentsLists();
//        AssetsDTO assetsDTO1 = AssetsMapper.mapToDTO(assets);
        List<InvestmentDTO> investmentDTOS = investments.stream().map((investment)->
                {
                    InvestmentDTO assetsDTO1=InvestmentMapper.mapToDTO(investment);
                    return assetsDTO1;
                }
        ).toList();
        return ResponseEntity.ok(investmentDTOS);
    }


private String getUserIdFromToken(String token) {
    return Jwts.parser()
            .setSigningKey(SECRET_KEY)
            .parseClaimsJws(token)
            .getBody()
            .getSubject();  // This is typically the user ID stored in the 'sub' claim
}
}
