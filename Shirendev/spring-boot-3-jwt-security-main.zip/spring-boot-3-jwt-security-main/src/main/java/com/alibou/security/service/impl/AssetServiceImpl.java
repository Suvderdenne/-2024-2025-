package com.alibou.security.service.impl;

import com.alibou.security.modal.Asset;
import com.alibou.security.payload.dto.AssetDTO;
import com.alibou.security.payload.dto.UserDTO;
import com.alibou.security.repository.AssetRepository;
import com.alibou.security.service.AssetService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AssetServiceImpl implements AssetService {

    private final AssetRepository assetRepository;


    @Override
    public List<Asset> getAllAssets() {
        return assetRepository.findAll();
    }

    @Override
    public Asset createAssets(AssetDTO req, UserDTO user) {
        Asset asset=new Asset();
        asset.setType(req.getType());
        asset.setSymbol(req.getSymbol());
        asset.setName(req.getName());
        asset.setCurrentPrice(req.getCurrentPrice());
        asset.setMarketCap(req.getMarketCap());
        asset.setVolume(req.getVolume());
        asset.setCurrency(req.getCurrency());
        asset.setStatus(req.getStatus());
        asset.setCreatedAt(req.getCreatedAt());
        asset.setUpdatedAt(req.getUpdatedAt());
        if (req.getIconBase64() != null) {
            asset.setIcon(Base64.getDecoder().decode(req.getIconBase64()));
        }
        return assetRepository.save(asset);

    }

    @Override
    public Asset updateAssets(AssetDTO assetDTO, UserDTO user, Long assetId) {
        return null;
    }

    @Override
    public List<Asset> getAssetsLists() {
        return assetRepository.findAll();
    }

    @Override
    public Asset getAssetsById(Long assetId) {
        return null;
    }

    @Override
    public Asset findBySymbol(String symbol) {
        return null;
    }

    @Override
    public List<Asset> searchAssetsBy(String type) {
        return List.of();
    }
}

//    private final InvestmentRepository investmentRepository;
//
//    @Override
//    public List<Investment> getAllInvestments() {
//
//        return List.of();
//    }
//
//    @Override
//    public Investment createInvestments(InvestmentDTO req, UserDTO user) {
//        Investment investment=new Investment();
////        investment.setName(req.getName());
////        investment.setType(req.getType());
////        investment.setSymbol(req.getSymbol());
////        investment.setUrl_icon(req.getUrl_icon());
//        return investmentRepository.save(investment);
//    }
//
//    @Override
//    public Investment updateInvestments(InvestmentDTO assets, UserDTO user, Long assetId) {
//        return null;
//    }
//
//    @Override
//    public List<Investment> getInvestmentsLists() {
//        return investmentRepository.findAll();
//    }
//
//    @Override
//    public Investment getInvestmentsById(Long assetId) {
//        return null;
//    }
//
//    @Override
//    public List<Investment> searchInvestmentsBy(String type) {
//        return List.of();
//    }
//}

