package com.alibou.security.modal;

import com.alibou.security.user.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "account") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;

    @Column(nullable = false)
    private String accountType;  // Type of account (e.g., "savings", "checking", "investment")

    @Column(nullable = false)
    private BigDecimal balance;  // Current balance of the account

    @Column(nullable = false)
    private String currency;  // Currency of the account (e.g., "USD")

    @Column(nullable = false)
    private String status;  // Status of the account (e.g., "active", "inactive")

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;  // The user who owns the account

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;  // Account creation date and time

    @Column(nullable = false)
    private LocalDateTime updatedAt;  // Account last update date and time

}
