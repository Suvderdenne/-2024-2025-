package com.alibou.security.modal;

import com.alibou.security.user.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "portfolio") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Portfolio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long portfolioId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;  // Represents the user who owns the portfolio

    @ManyToOne
    @JoinColumn(name = "asset_id", nullable = false)
    private Asset asset;  // Represents the asset held in the portfolio

    @Column(nullable = false)
    private BigDecimal quantity;  // The quantity of the asset owned by the user

    @Column(nullable = false)
    private BigDecimal purchasePrice;  // The price at which the asset was purchased

    @Column(nullable = false)
    private LocalDateTime purchaseDate;  // The date when the asset was purchased and added to the portfolio

    @Column
    private BigDecimal currentValue;  // The current market value of the asset (optional, can be updated based on market data)

    @Column(nullable = false)
    private BigDecimal totalValue;  // The total value of the asset in the portfolio (current_value * quantity)

    @Column(nullable = false)
    private String status;  // The status of the asset (e.g., "active", "inactive")
}
