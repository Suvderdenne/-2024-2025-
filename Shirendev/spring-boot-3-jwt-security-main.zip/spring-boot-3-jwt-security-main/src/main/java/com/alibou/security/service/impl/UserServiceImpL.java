package com.alibou.security.service.impl;

import com.alibou.security.exception.UserException;
import com.alibou.security.service.UserService;
import com.alibou.security.user.User;
import com.alibou.security.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpL implements UserService {


    private final UserRepository userRepository;

    @Override
    public User createUser(User user) {
            return userRepository.save(user);
    }

    @Override
    public User getUserById(Long id) throws UserException {
        Optional<User> otp = userRepository.findById(id);
        if (otp.isPresent()){
            return otp.get();
        }
        throw new UserException("user not found");
    }

    @Override
    public List<User> getAllUsers() {
        return List.of();
    }

    @Override
    public void deleteUser(Long id) throws UserException {
        Optional<User> otp = userRepository.findById(id);
        if (otp.isEmpty()){
            throw new UserException("user not found with id "+ id);
        }
        userRepository.deleteById(otp.get().getUserId());
    }

    @Override
    public User updateUser(String email, User user) throws UserException {
        Optional<User> otp = userRepository.findByEmail(email);
        if (otp.isEmpty()){
            throw new UserException("user not found with id "+ email);
        }
        System.out.println("user " + otp.get().getUserId());
        User existingUser=otp.get();
        existingUser.setFirstname(user.getFirstname());
        existingUser.setLastname(user.getLastname());
        existingUser.setEmail(user.getEmail());
        existingUser.setPhone(user.getPhone());
        existingUser.setDate_of_birth(user.getDate_of_birth());
        existingUser.setAddress(user.getAddress());
        existingUser.setRegno(user.getRegno());
//        existingUser.setUpdatedAt(new Date());

        return userRepository.save(existingUser);
    }


}
