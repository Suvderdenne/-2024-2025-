package com.alibou.security.modal;

import com.alibou.security.user.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transaction") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;  // Represents the user who initiated the transaction

    @Column(nullable = false)
    private String transactionType;  // Type of transaction (e.g., "deposit", "withdrawal")

    @Column(nullable = false)
    private BigDecimal amount;  // Amount involved in the transaction

    @Column(nullable = false)
    private String status;  // Status of the transaction (e.g., "completed", "pending")

    @Column(nullable = false)
    private LocalDateTime transactionDate;  // Date and time when the transaction occurred

    private String description;  // Optional description for the transaction

    private BigDecimal accountBalance;  // Account balance after the transaction (optional)

    private String transactionReference;  // Optional reference code for the transaction

}
