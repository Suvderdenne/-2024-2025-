package com.alibou.security.payload.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Data
@Getter
@Setter
public class UserDTO {

    private Long id;
    private String firstname;
    private String lastname;
    private List<String> images;
    private String address;
    private String phoneNumber;
    private String email;
}
