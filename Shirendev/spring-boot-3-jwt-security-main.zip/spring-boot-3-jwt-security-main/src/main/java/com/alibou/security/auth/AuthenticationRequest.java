package com.alibou.security.auth;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuthenticationRequest {

//  @Column(nullable = false)
  private String email;

//  @Column(nullable = false)
  private String password;
}
