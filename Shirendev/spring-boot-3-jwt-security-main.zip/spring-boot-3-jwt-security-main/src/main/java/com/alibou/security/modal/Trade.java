package com.alibou.security.modal;

import com.alibou.security.user.User;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "trade") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Trade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tradeId;

    @ManyToOne
    @JoinColumn(name = "buyer_id", nullable = false)
    private User buyer;  // Represents the buyer

    @ManyToOne
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;  // Represents the seller

    @ManyToOne
    @JoinColumn(name = "asset_id", nullable = false)
    private Asset asset;  // Represents the asset being traded

    @Column(nullable = false)
    private int quantity;  // The quantity of the asset being traded

    @Column(nullable = false)
    private BigDecimal price;  // The price per unit of the asset

    @Column(nullable = false)
    private BigDecimal totalValue;  // Total value of the trade (price * quantity)

    @Column(nullable = false)
    private LocalDateTime tradeTime;  // Date and time when the trade was executed

    @Column(nullable = false)
    private String status;  // Status of the trade (e.g., "completed", "pending")

    @Column(nullable = false)
    private String tradeType;  // Type of trade ("buy", "sell")

}
