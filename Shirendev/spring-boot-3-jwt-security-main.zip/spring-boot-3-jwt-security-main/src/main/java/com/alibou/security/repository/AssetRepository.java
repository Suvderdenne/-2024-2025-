package com.alibou.security.repository;

import com.alibou.security.exception.UserException;
import com.alibou.security.modal.Asset;
import com.alibou.security.modal.Investment;
import com.alibou.security.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AssetRepository extends JpaRepository<Asset, Long> {

    @Query(
            "select a from Asset a where" +
                    "(lower(a.name) like lower(concat('%', :keyword, '%')) OR  " +
//                    "lower(a.name) like lower(concat('%', :keyword, '%')) OR " +
                    "lower(a.type) like lower(concat('%', :keyword, '%')))"
    )
    List<Asset> searchInvestmentBy(@Param("keyword") String keyword);


    @Query(
            "select a from Asset a where" +
                    "(lower(a.symbol) like lower(concat('%', :symbol, '%')))"
    )
    Asset findBySymbol(@Param("symbol") String symbol);
}
