package com.alibou.security.service;


import com.alibou.security.modal.Investment;
import com.alibou.security.payload.dto.InvestmentDTO;
import com.alibou.security.payload.dto.UserDTO;


import java.util.List;



public interface InvestmentService {

    List<Investment> getAllInvestments();

    Investment createInvestments(InvestmentDTO investment, UserDTO user);

    Investment updateInvestments(InvestmentDTO investment, UserDTO user, Long assetId);

    List<Investment> getInvestmentsLists();

    Investment getInvestmentsById(Long assetId);

//    Assets getAssetByOwnerId(Long ownerId);

    List<Investment> searchInvestmentsBy(String type);

}
