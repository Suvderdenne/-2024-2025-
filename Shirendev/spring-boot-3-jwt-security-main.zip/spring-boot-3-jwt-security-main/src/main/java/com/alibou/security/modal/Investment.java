package com.alibou.security.modal;


import com.alibou.security.user.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "investment") // Use a non-reserved keyword
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Investment {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    @Column(nullable = false)
//    private String type; //
//    @Column(nullable = false)
//    private String name;    //TESLE
//    @Column(nullable = false)
//    private  String symbol;
//    private String url_icon;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long investmentId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;  // The user who made the investment

    @ManyToOne
    @JoinColumn(name = "portfolio_id", nullable = false)
    private Portfolio portfolio;  // The portfolio in which the investment is held

    @Column(nullable = false)
    private String investmentType;  // Type of the investment (e.g., "stock", "bond", "mutual fund")

    @Column(nullable = false)
    private BigDecimal amountInvested;  // The amount of money invested

    @Column(nullable = false)
    private String currency;  // Currency of the investment (e.g., "USD")

    @Column(nullable = false)
    private String investmentStatus;  // Status of the investment (e.g., "active", "closed")

    @Column(nullable = false)
    private LocalDateTime purchaseDate;  // Date when the investment was made

    @Column(nullable = false)
    private BigDecimal currentValue;  // The current value of the investment

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;  // Record creation timestamp

    @Column(nullable = false)
    private LocalDateTime updatedAt;  // Record last updated timestamp


}