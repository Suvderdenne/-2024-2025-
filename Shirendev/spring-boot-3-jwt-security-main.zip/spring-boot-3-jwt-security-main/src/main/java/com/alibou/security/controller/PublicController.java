package com.alibou.security.controller;

import com.alibou.security.mapper.AssetMapper;
import com.alibou.security.modal.Asset;
import com.alibou.security.modal.MarketData;
import com.alibou.security.payload.dto.AssetDTO;
import com.alibou.security.service.AssetService;
import com.alibou.security.service.MarketDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

@RestController
@RequestMapping("/app")
@RequiredArgsConstructor
public class PublicController {

    private final AssetService assetService;
    private final MarketDataService marketDataService;

    @GetMapping("/assets")
    public ResponseEntity<List<AssetDTO>> getAssets() throws IOException, InterruptedException {

        List<Asset> allAssets=assetService.getAllAssets();
//        AssetsDTO assetsDTO1 = AssetsMapper.mapToDTO(assets);
        List<AssetDTO> assetDTOS = allAssets.stream().map((asset)->
                {
                    AssetDTO assetsDTO1 = AssetMapper.mapToDTO(asset);
                    return assetsDTO1;
                }
        ).toList();
//        @Scheduled(cron = "0 */15 * * * *")  // Runs Every 15 mins
//        public void syncDailyMarketData() {
            System.out.println("Running daily market data sync...");

            // You can loop over asset symbols
            List<String> symbols = List.of("MSFT", "AAPL");

            for (String symbol : symbols) {
                try {
                    MarketData data = marketDataService.fetchAndSaveMarketData(symbol);
                    System.out.println("Synced: " + symbol);
                } catch (Exception e) {
                    System.err.println("Failed to sync " + symbol + ": " + e.getMessage());
                }
            }
//        }
        return ResponseEntity.ok(assetDTOS);
    }

}
